<?php
/**
 * @var $optin_url string
 * @var $optout_url string
 */
?>
